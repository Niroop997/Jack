import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CarService } from 'src/app/car.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
public regNo: String='';
public carDetails: any;
public displayedColumns: String[]= ['price', 'year', 'place'];
  constructor(private route: ActivatedRoute, private router: Router,private carService: CarService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params=>{this.regNo=params.regNumber});
    this.getVehicleDetails();
  }
  getVehicleDetails(){
this.carService.getDetails(this.regNo).then(res=>{
  this.carDetails=res;
})
  }

  changeCar(){
    this.router.navigate(['/']);
  }


}
