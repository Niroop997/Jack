import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CarService {

  private apiUrl = 'http://localhost:4200/api/';
  private JSON=[{
    "place":"Kazhakuttom",
    "year":"2020",
    "price":"200000"
  },{
    "place":"Kundara",
    "year":"2010",
    "price":"150000"
  },{
    "place":"Kochi",
    "year":"2015",
    "price":"100000"
  }];
    constructor(private http:HttpClient) { }

    getDetails(regNo: String){
        const url = this.getUrl(regNo);
   return this.http.get(url).toPromise().then(res=>{
     return res
   }, err=>{
     return this.JSON
   })
    }
  
    getUrl(path: String){
      return this.apiUrl+path;
    }
  }
  